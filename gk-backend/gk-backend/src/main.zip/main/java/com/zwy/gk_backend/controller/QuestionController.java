package com.zwy.gk_backend.controller;

import com.zwy.gk_backend.entity.Question;
import com.zwy.gk_backend.mapper.QuestionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/question")
@CrossOrigin // ⚠️超级关键：允许跨域请求！因为Vue是5173端口，后端是8080端口
public class QuestionController {

    // 把刚才写的 Mapper 自动装配进来，就像雇佣了一个打工人
    @Autowired
    private QuestionMapper questionMapper;

    // 当浏览器访问 /api/question/list 时，执行这个方法
    @GetMapping("/list")
    public List<Question> getQuestionList() {
        // selectList(null) 意思是没有任何条件，直接查出表里的所有数据！
        return questionMapper.selectList(null);
    }
}